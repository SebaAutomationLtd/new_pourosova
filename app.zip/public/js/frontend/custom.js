$(function () {
    $('marquee').mouseover(function () {
        $(this).attr('scrollamount', 0);
    }).mouseout(function () {
        $(this).attr('scrollamount', 5);
    });
});