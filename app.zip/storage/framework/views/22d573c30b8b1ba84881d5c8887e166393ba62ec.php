<section id="main" class="mt-2 mt-md-3">
        <div class="container">
            <div class="form-row">
                <!-- Left Column Start -->
                <div class="col-md-3 order-md-1 order-2" id="left">

                    <div>
                        <div>


                            <div class="mayor-section">
                                <div class="content-header">
                                    <h5>
                                        <a href="<?php echo e(route('mayor.contact')); ?>">
                                            সম্মানিত মেয়র
                                        </a>
                                    </h5>
                                </div>
                                <a href="#">
                                    <div class="mayor">
                                        <div class="text-center">
                                            <img class="rounded img-fluid w-100 d-block" src="<?php echo e(asset('img/'. ($mayor ? $mayor->image : ''))); ?>"
                                                alt="">
                                            <h5 class="mt-2 mb-0"><?php echo e($mayor->name ?? ''); ?></h5>
                                            <div>
                                                <?php echo e($website_data->title_bangla ?? ''); ?>

                                            </div>
                                            <div>
                                                <?php echo e($mayor->place ?? ''); ?>

                                            </div>

                                        </div>
                                    </div>
                                </a>
                            </div>


                            <div class="councilor-section mt-3">
                                <div class="content-header">
                                    <h5>
                                        <a href="<?php echo e(route ('counselor')); ?>">
                                            সম্মানিত কাউন্সিলরগণ
                                        </a>
                                    </h5>
                                </div>

                                <div class="councilor">
                                    <div class="text-center">
                                        <div class="form-row">

                                            <?php $__empty_1 = true; $__currentLoopData = $councilors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $councilor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                            <!-- Councilor By Ward -->
                                            <div class="col-6">
                                                <a href="#">
                                                    <div class="info">
                                                        <img class="img-fluid w-100 d-block"
                                                            src="<?php echo e(asset('councilor/img/'.$councilor->photo)); ?>" alt="">
                                                        <h5 class="m-0 title">ওয়ার্ড <?php echo e($councilor->ward_no ?? ''); ?></h5>
                                                    </div>
                                                </a>
                                            </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- Councilor Section End  -->



                            <!-- Female Councilor Section Start  -->
                            <div class="councilor-section mt-3">
                                <div class="content-header">
                                    <h5>
                                        <a href="">
                                            সংরক্ষিত আসনের কাউন্সিলরগণ
                                        </a>
                                    </h5>
                                </div>


                                <!--  Councilor By Ward -->
                                <div class="councilor">
                                    <div class="text-center">
                                        <div class="form-row">

                                        <?php $__empty_1 = true; $__currentLoopData = $female_councilors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $councilor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                            <!-- Councilor By Ward -->
                                            <div class="col-6">
                                                <a href="#">
                                                    <div class="info">
                                                        <img class="img-fluid w-100 d-block"
                                                            src="<?php echo e(asset('councilor/img/'.$councilor->photo)); ?>" alt="">
                                                        <h5 class="m-0 title">ওয়ার্ড <?php echo e($councilor->ward_no ?? ''); ?></h5>
                                                    </div>
                                                </a>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>



                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Female Councilor Section End -->

                            <!-- Important Links Start -->
                            <div class="application-link-section mt-3">
                                <div class="content-header">
                                    <h5>
                                        <a>
                                            গুরুত্বপূর্ণ আবেদনপত্র
                                        </a>
                                    </h5>
                                </div>

                                <div class="app-links ">
                                    <div>
                                        <div class="list-group">
                                            <?php $__empty_1 = true; $__currentLoopData = $left_apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <a href="<?php echo e($data->link ?? ''); ?>" class="list-group-item list-group-item-action">
                                                <?php echo e($data->title ?? ''); ?>

                                            </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Important Links Start -->


                            <!-- Hotline Start -->
                            <div class="application-link-section mt-3">

                                <?php $__empty_1 = true; $__currentLoopData = $left_banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $left_banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="content-header">
                                    <h5>
                                        <a>
                                            <?php echo e($left_banner->title ?? ''); ?>

                                        </a>
                                    </h5>
                                </div>

                                <div class="app-links ">
                                    <div>
                                        <div>
                                            <img class="d-block w-100" src="<?php echo e(asset('leftside/img/'.$left_banner->photo)); ?>" alt="">
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                            <!-- Hotline End -->
                        </div>
                    </div>

                </div>
                <!-- Left Column End -->


<?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/frontend/include/leftbar.blade.php ENDPATH**/ ?>