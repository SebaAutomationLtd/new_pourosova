
                <!-- Right Column Start -->
                <div class="col-md-3 order-3">
                    <div id="right-sidebar">
                        <div>

                            <div class="add">
                                <img src="<?php echo e(asset('rightside/img/'. ($right_top_banner ? $right_top_banner->photo : ''))); ?>" alt="">
                            </div>


                            <!-- Notice Section Start -->
                            <div class="notice mb-3 mt-1">
                                <div class="content-header">
                                    <h5>
                                        <a href="">
                                            আপডেট নোটিশ
                                        </a>
                                    </h5>
                                </div>

                                <div class="content-body">
                                    <div class="">
                                        <marquee scrollamount='3' behavior="" direction="up">

                                            <?php $__currentLoopData = $marquees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marquee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e($marquee->link); ?>" class="item">
                                                <?php echo e($marquee->title); ?>

                                                <!-- <small>০১-০১-২০২১</small> -->
                                            </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </marquee>

                                    </div>
                                </div>

                            </div>
                            <!-- Notice Section Start -->


                            <!-- Links Start -->
                            <div class="links">
                                <div class="content-header">
                                    <h5>
                                        <a>
                                            গুরুত্বপূর্ণ লিঙ্কসমূহ
                                        </a>
                                    </h5>
                                </div>
                                <div class="content-body">
                                    <div class="list-group">
                                        <?php $__currentLoopData = $right_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($link->link ?? ''); ?>" class="list-group-item list-group-item-action">
                                            <?php echo e($link->title ?? ''); ?>

                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                            </div>
                            <!-- Links End -->

                            <?php $__empty_1 = true; $__currentLoopData = $right_banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $right_banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="mt-3">
                                    <div class="content-header">
                                        <h5>
                                            <a>
                                                <?php echo e($right_banner->title ?? ''); ?>

                                            </a>
                                        </h5>
                                    </div>

                                    <div class="app-links ">
                                        <div>
                                            <div>
                                                <img class="d-block w-100" src="<?php echo e(asset('rightside/img/'.$right_banner->photo ?? '')); ?>" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                        </div>
                    </div>
                </div>
                <!-- Right Column End -->

            </div>
        </div>
    </section>
<?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/frontend/include/rightbar.blade.php ENDPATH**/ ?>