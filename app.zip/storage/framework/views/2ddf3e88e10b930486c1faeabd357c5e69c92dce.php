
<?php $__env->startSection('header'); ?>
    <section class="content-header pl-3">
        <h1>ওয়েবসাইট</h1>
        <ol class="breadcrumb">
            <li>
                <a href="/admin">
                    <i class="fa fa-fw ti-home"></i> ড্যাশবোর্ড
                </a>
            </li>


        </ol>
    </section>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>