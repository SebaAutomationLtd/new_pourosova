<header class="header">
    <nav class="navbar navbar-static-top" role="navigation">
        <a href="index.html" class="logo text-left">
            <!-- Add the class icon to your logo image or logo icon to add the marginin -->
            <img style="max-width: 210px;" src="<?php echo e(asset('Admin')); ?>/img/logo.svg" alt="logo" />
        </a>
        <!-- Header Navbar: style can be found in header-->
        <!-- Sidebar toggle button-->
        <div class="mr-auto">
            <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button"> <i
                    class="fa fa-fw ti-menu"></i>
            </a>
        </div>
        <?php echo $__env->make('admin.layout.inc.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</header>
<?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/admin/layout/inc/topmenu.blade.php ENDPATH**/ ?>