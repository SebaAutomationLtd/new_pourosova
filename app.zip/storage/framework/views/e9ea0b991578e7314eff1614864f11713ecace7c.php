<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.include.leftbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Column End -->
<div class="col-md-6 order-md-2 order-1" id="content">
                    <div>
                        <div>
                            <!--Main Slider Start-->
                            <div id="main-slider" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li class="active" data-target="#main-slider" data-slide-to="0"
                                        aria-current="location"></li>
                                    <li data-target="#main-slider" data-slide-to="1"></li>
                                    <li data-target="#main-slider" data-slide-to="2"></li>
                                    <li data-target="#main-slider" data-slide-to="3"></li>
                                    <li data-target="#main-slider" data-slide-to="4"></li>
                                </ol>
                                <div class="carousel-inner">
                                    <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                                            <img class="d-block w-100" src="<?php echo e(asset('img/'.$slider->image ?? '')); ?>" alt="">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>

                                </div>
                                <a class="carousel-control-prev" href="#main-slider" data-slide="prev" role="button">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#main-slider" data-slide="next" role="button">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                            <!--Main Slider Start-->


                            <!--Sub Notice Start-->
                            <div class="sub-notice my-3">
                                <div>
                                    <a href="">
                                        তারাব পৌরসভার সকল সেবা এখন অনলাইনে। নিবন্ধন করুন DigitalPaurashava.gov.bd তে।
                                    </a>
                                </div>
                            </div>
                            <!--Sub Notice End-->


                           <!--Sub Notice Start-->
                            <div class="welcome my-3">
                                <div class="content-header mb-3">
                                    <h5 class="m-0 font-weight-bold">স্বাগতম</h5>
                                </div>
                                <div class="padding-15">
                                    <h5><?php echo e($about_pauro->title ?? ''); ?></h5>
                                   <?php echo e($about_pauro->description ?? ''); ?>

                                </div>
                            </div>
                            <!--Sub Notice End-->


                            <!--Service Start-->
                            <div class="service my-3">

                                <div class="content-header mb-3">
                                    <h5 class="m-0 font-weight-bold">আমাদের সেবাসমূহ</h5>
                                </div>
                                <div class="content">
                                    <div class="padding-15">
                                        <!--Service Item Start-->
                                        <div class="form-row">

                                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!-- Service Item -->
                                            <div class="col-md-4 col-6">
                                                <a href="<?php echo e($service->link); ?>">
                                                    <div class="card mt-2">
                                                        <div class="card-body text-center">

                                                            <!-- <i class="fa fa-house-user"></i> -->
                                                            <img src="<?php echo e(asset('img/'.$service->image ?? '')); ?>" style="height: 80px; width: 80px;">
                                                            <div class="title">
                                                                <?php echo e($service->title ?? ''); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </div>




                                    </div>
                                </div>
                            </div>
                            <!--Service Item End-->


                            <!-- Awareness Start-->
                            <div class="aware my-3 mt-4">
                                <div class="content-header mb-3">
                                    <h5 class="m-0 font-weight-bold">সচেতনতা</h5>
                                </div>
                                <div>
                                    <img class="d-block w-100" src="images/Awareness.jpg" alt="">
                                </div>
                            </div>
                            <!-- Awareness End-->

                        </div>
                    </div>
                </div>
                <!-- Content Column End -->

<?php echo $__env->make('frontend.include.rightbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/frontend/index.blade.php ENDPATH**/ ?>