
<?php $__env->startSection('header'); ?>
    <section class="content-header pl-3">
        <h1>ওয়েবসাইট</h1>
        <ol class="breadcrumb">
            <li>
                <a href="">
                    <i class="fa fa-fw ti-home"></i> এসেসমেন্ট নিবন্ধন
                </a>
            </li>
            <!-- <li>সেবা কার্ড একটিভ প্যানেল</li> -->

        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="content-wrapper">


        <section class="content  card card-primary">
            <div class="container-fluid">
                <div class="row mb-2" style="margin-top: 20px">
                    <div class="col-sm-6">
                        <h4> বসতবাড়ী হোল্ডিং আপডেট করুন</h4>
                    </div>
                    <!-- <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">হোম</a></li>
                            <li class="breadcrumb-item active"> বসতবাড়ী হোল্ডিং আপডেট করুন</li>
                        </ol>
                    </div> -->
                </div>
                <div class="row">
                    <div class="col-md-12">
          

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
                        <div class=" website-form form-group">
                            <!-- <div class="card-header">
                                <h3 class="card-title"> বসতবাড়ী হোল্ডিং আপডেট করুন</h3>
                            </div> -->
                            <form role="form" action="<?php echo e(route('update.bosot-bari', $user->id)); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                 <?php
                                    $user_info = DB::table('users')->where('id',$user->user_id)->first();

                                    ?>

                                <h5><u>খানা প্রধানের তথ্য</u></h5>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label for="name" class="col-form-label">নাম <span
                                                style="color: red">*</span></label>
                                        <input type="text" name="name" value="<?php echo e(old('name', $user_info->name)); ?>" class="form-control"
                                            id="name" placeholder="নাম" autocomplete="off" required="">

                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="col-sm-4" id="father_name">
                                        <label for="father_name" class="col-form-label">
                                            <select id="gurdian_status" name="gurdian_status">
                                                <option <?php echo old('gurdian_status', $user->spouse) == null ? 'selected="selected"' : ''; ?>  value="father" >পিতার নাম </option>
                                                <option <?php echo old('gurdian_status', $user->father) == null ? 'selected="selected"' : ''; ?> value="husband" >স্বামীর নাম</option>
                                            </select>
                                            <span style="color: red">*</span></label>
                                        <?php if($user->spouse == null): ?>
                                            <input type="text" name="father_name" value="<?php echo e(old('father_name', $user->father)); ?>"
                                                class="form-control gurdian_status" id="father_name" autocomplete="off"
                                                placeholder="পিতার নাম " required="">

                                                <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <?php else: ?>
                                            <input type="text" name="father_name" value="<?php echo e(old('father_name',$user->spouse)); ?>"
                                                class="form-control gurdian_status" id="husband_name" autocomplete="off"
                                                placeholder="স্বামীর নাম " required="">

                                                <?php $__errorArgs = ['husband_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-4">
                                        <label for="mother_name" class="col-form-label">মাতার নাম <span
                                                style="color: red">*</span></label>
                                        <input type="text" name="mother_name" value="<?php echo e(old('mother_name', $user->mother)); ?>"
                                            class="form-control" id="mother_name" placeholder="মায়ের নাম"
                                            autocomplete="off" required="">

                                            <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-sm-4">
                                        <label for="inputPassword3" class="col-form-label">লিঙ্গ <span
                                                style="color: red">*</span></label>
                                        <select name="gender" id="gender" class="form-control" required="">
                                            <option value="" selected="" disabled="">নির্বাচন করুন</option>
<?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($gender->id); ?>" <?php echo old('gender', $user->gender) == $gender->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($gender->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        </select>

                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-sm-4">
                                        <label for="inputPassword3" class="col-form-label">বৈবাহিক অবস্থা<span
                                                style="color: red">*</span></label>
                                        <select name="martial" id="martial_status" class="form-control" required="">
                                              <option value="" >নির্বাচন করুন</option>
<?php $__currentLoopData = $marital_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($marital->id); ?>" <?php echo old('martial', $user->marital_status) == $marital->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($marital->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        </select>

                                        <?php $__errorArgs = ['martial_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>


                                    <div class="col-sm-4">
                                        <label for="Birthdatepicker" class="col-form-label">জন্ম তারিখ</label>
                                       
                <input class="form-control" type="date" value="<?php echo e(old('dob',$user->dob)); ?>" name="dob">

                                                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger">
                                                        <strong><?php echo e($message); ?></strong>
                                                </small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>



                                    <div class="col-sm-3">
                                        <label for="nid_birth" class="col-form-label">
                                            <select id="birth_nid" name="birth_nid">
                                                <option <?php echo old('birth_nid', $user->birth_certificate) == null ? 'selected="selected"' : ''; ?> value="nid">এনআইডি নম্বর</option>
                                                <option value="birth_id_no" <?php echo old('birth_nid', $user->nid) == null ? 'selected="selected"' : ''; ?>>জন্ম নিবন্ধন নম্বর</option>
                                            </select>
                                            <span style="color: red">*</span></label>
                                        <?php if($user->birth_certificate == null): ?>
                                            <input type="text" name="nid" value="<?php echo e(old('nid',$user->nid)); ?>"
                                                class="form-control birth_nid" id="nid_birth" autocomplete="off"
                                                placeholder="এনআইডি নম্বর" required="">

                                                <?php $__errorArgs = ['nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <?php else: ?>
                                            <input type="text" name="nid"
                                                value="<?php echo e(old('nid',$user->birth_certificate)); ?>" class="form-control birth_nid"
                                                id="nid_birth" autocomplete="off" placeholder="এনআইডি নম্বর" required="">

                                                <?php $__errorArgs = ['birth_certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-3">
                                        <label for="mobile" class="col-form-label">মোবাইল<span
                                                style="color: red">*</span></label>
                                         <input type="text" oninput="contactNumber(this.id);" maxlength="11" class="form-control mobilenumber" id="mobile"
                                   placeholder="মোবাইল" name="mobilenumber" value="<?php echo e(old('mobilenumber',$user->mobile)); ?>" required="">
                                   <span id="dupmobile" style="color: red;"></span>

                                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-sm-3">
                                        <label for="religion_id" class="col-form-label">ধর্ম  <span
                                                style="color: red">*</span></label>
                                        <select name="religion_id" id="religion_id" class="form-control"  required="">
                                             <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                           <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($religion->id); ?>" <?php echo old('religion_id', $user->religion) == $religion->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($religion->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                        </select>

                                        <?php $__errorArgs = ['religion_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-sm-3" style="margin-top: 5px;">
                                        <div class="form-group">
                                            <label for="family_class">পরিবারের শ্রেণী</label>
                                            <select id="family_class" name="family_class" class="form-control">
                                                <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                 <?php $__currentLoopData = $family_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familyclass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($familyclass->id); ?>" <?php echo old('family_class', $user->family_class_id ) == $familyclass->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($familyclass->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                            <?php $__errorArgs = ['family_class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>


                                    <div class="col-sm-3" style="margin-top: 5px;">
                                        <div class="form-group">
                                            <label for="family_class">পরিবারের জনসংখ্যা (পুরুষ)</label>
                                            <input value="<?php echo e(old('member_male',$user->total_male)); ?>" name="member_male" type="number"
                                                class="form-control" placeholder="পরিবারের জনসংখ্যা (পুরুষ)">

                                                <?php $__errorArgs = ['member_male'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-sm-3" style="margin-top: 5px;">
                                        <div class="form-group">
                                            <label for="family_class">পরিবারের জনসংখ্যা (মহিলা)</label>
                                            <input value="<?php echo e(old('member_female',$user->total_female)); ?>" name="member_female" type="number"
                                                class="form-control" placeholder="পরিবারের জনসংখ্যা (মহিলা)">

                                                <?php $__errorArgs = ['member_female'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                </div>
                                <br />

                                <div class="form-group">







                                    <!-- Addess Information -->
                                    <div class="form-group">
                                        <h5><u>ঠিকানার তথ্য</u> </h5>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label for="ward_id" class="col-form-label">ওয়ার্ড নং</label>
                                                <select name="ward_id" id="ward_id" class="form-control"  >
                                                    <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                   
                                                    <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($ward->id); ?>"<?php echo old('ward_id', $user->ward_id ) == $ward->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($ward->ward_no); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php $__errorArgs = ['ward_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="village_id" class="col-form-label">গ্রাম </label>
                                                <select name="village_id" id="village_id" class="form-control"
                                                     >
                                                    <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                   
                                                    <?php $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $village): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($village->id); ?>" <?php echo old('village_id', $user->village_id ) == $village->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($village->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php $__errorArgs = ['village_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="holding_no" class="col-form-label">হোল্ডিং নং <span
                                                        style="color: red">*</span> </label>
                                                <input type="text" name="holding_no" value="<?php echo e(old('holding_no',$user->holding_no)); ?>"
                                                    class="form-control" id="holding_no" placeholder="হোল্ডিং নং"
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['holding_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>


                                            <div class="col-sm-4">
                                                <label for="post_office_id" class="col-form-label">ডাক ঘর</label>
                                                <select name="post_office_id" id="post_office_id" class="form-control">
                                                    <option value="" selected="" disabled="">নির্বাচন করুন</option>

                                                    <?php $__currentLoopData = $post_offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postoffice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($postoffice->id); ?>" <?php echo old('post_office_id', $user->post_office_id ) == $postoffice->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($postoffice->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['post_office_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="post_office_id" class="col-form-label">বিদ্যুৎ সুবিধাভোগি
                                                    কিনা?</label>
                                                <select name="biddut"   class="form-control">
                                                    <option value="">নির্বাচন করুন</option>
                                                    <option <?php echo e(old('biddut',$user->biddut) == 1 ? 'selected' : ''); ?> value="1">হ্যা
                                                    </option>
                                                    <option <?php echo e(old('biddut',$user->biddut) == 2 ? 'selected' : ''); ?> value="2">না
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['biddut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="post_office_id" class="col-form-label">স্যানিটেশনের তথ্য</label>
                                                <select name="sanitation"   class="form-control">
                                                     <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                    <?php $__currentLoopData = $sanitations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sanitation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($sanitation->id); ?>" <?php echo old('sanitation', $user->sanitation_id ) == $sanitation->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($sanitation->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                </select>
                                                <?php $__errorArgs = ['sanitation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>


                                        </div>
                                    </div>

                                    <!-- Other Information -->
                                    <div class="form-group">
                                        <h5><u>অন্যান্য তথ্য</u> </h5>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label for="type_house" class="col-form-label">বাড়ির ধরণ<span
                                                        style="color: red">*</span></label>
                                                <input type="hidden" name="house_tax_rate" id="house_tax_rate"
                                                    value="<?php echo e($user->yearly_vat); ?>">

                                                <select name="type_house" id="type_house" class="form-control" required="">
                                                    <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                     <?php $__currentLoopData = $house_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($house_type->id); ?>"  <?php echo old('type_house', $user->house_type_id ) == $house_type->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($house_type->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                                </select>
                                                <?php $__errorArgs = ['type_house'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="number_room" class="col-form-label">রুম পরিমাণ<span
                                                        style="color: red">*</span></label>
                                                <input type="text" name="number_room" value="<?php echo e(old('number_room',$user->total_room)); ?>"
                                                    class="form-control" id="number_room" placeholder="রুম পরিমাণ"
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['number_room'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="height" class="col-form-label">দৈর্ঘ<span style="color: red">*</span></label>
                                                <input type="text" name="height" value="<?php echo e(old('height',$user->height)); ?>" class="form-control <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="দৈর্ঘ" autocomplete="off" required="">
                                                <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            
                                            <div class="col-md-4">
                                                <label for="width" class="col-form-label">প্রস্থ<span style="color: red">*</span></label>
                                                <input type="text" name="width" value="<?php echo e(old('width',$user->width)); ?>" class="form-control <?php $__errorArgs = ['width'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="প্রস্থ" autocomplete="off" required="">
                                                <?php $__errorArgs = ['width'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-sm-4">
                                                <label for="monthly_income" class="col-form-label">মাসিক আয় </label>
                                                <input type="number" name="monthly_income"
                                                    value="<?php echo e(old('monthly_income',$user->monthly_income)); ?>"
                                                    class="form-control monthly_income" id="house_annual_val"
                                                    placeholder="মাসিক আয়" autocomplete="off">

                                                    <?php $__errorArgs = ['monthly_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="house_year_value" class="col-form-label">বাড়ির বার্ষিক
                                                    মান</label>
                                                <input type="number" name="house_year_value"
                                                    value="<?php echo e(old('house_year_value',$user->yearly_value)); ?>"
                                                    class="form-control house_year_value" id="house_annual_val"
                                                    placeholder="বাড়ির বার্ষিক মান" autocomplete="off">

                                                    <?php $__errorArgs = ['house_year_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="yearly_vat" class="col-form-label">বার্ষিক কর</label>

                                                <input type="number" name="yearly_vat" class="form-control yearly_vat"
                                                    placeholder="বার্ষিক কর" value="<?php echo e(old('yearly_vat',$user->yearly_vat)); ?>">


                                            </div>

                                            <div class="col-sm-4">
                                                <label for="occupation_id" class="col-form-label"  >পেশা </label>

                                                <select name="occupation_id" id="occupation_id" class="form-control">
                                                    <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                    <?php $__currentLoopData = $occupations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ocupation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($ocupation->id); ?>" <?php echo old('occupation_id', $user->occupation_id ) == $ocupation->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($ocupation->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                                <?php $__errorArgs = ['occupation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="last_tax_year" class="col-form-label">সর্বশেষ ট্যাক্স পরিশোধ
                                                    অর্থবছর</label>
                                                <select name="last_tax_year" id="last_tax_year" class="form-control"
                                                     >
                                                    <option value="" >নির্বাচন করুন</option>
                                                   <?php
                                        $date_past = date("Y", strtotime('-10 year')); 
$date_year = date("Y");


                                                   ?>
                                                   <?php for($i=$date_year;$i>=$date_past;$i--): ?>
                                                    <option <?php echo old('last_tax_year', $user->last_tax_year ) == $i ? 'selected="selected"' : ''; ?> value="<?php echo e($i); ?>">
                                                        <?php echo e($i); ?></option>
                                                    <?php endfor; ?>
                                                 
                                                </select>
                                               
                                                <?php $__errorArgs = ['last_tax_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <h5><u>ছবি </u> </h5>
                                            <div class="row">
                                                <div class="col-sm-4">
                            <label for="photo" class="col-form-label">ছবি সংযুক্ত করুন</label>
                            <input type="file" id="photo" name="photo" onchange="loadFile(event)" class="form-control">
                            <span id="perror" style="color: red;"></span>
                        </div>
                        <div class="col-sm-4">
                            <img id="output" src="<?php if($user->photo): ?> <?php echo e(asset('img/'.$user->photo)); ?> <?php else: ?> https://via.placeholder.com/150 <?php endif; ?>" class="img-responsive img-thumbnail img-fluid">
                        </div>
                                            </div>
                                        </div>

                                        <!-- Other Information -->
                                        <br>
                                        <div class="form-group">
                                            <h5><u>পেমেন্ট সংগ্রহ করুন</u> </h5>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label for="service_charge" class="col-form-label">নিবন্ধন চার্জ<span
                                                            style="color: red">*</span></label>
                                                    <input type="text" name="service_charge"
                                                        value="<?php echo e(old('service_charge',$user->service_charge)); ?>" class="form-control"
                                                        id="service_charge" placeholder="নিবন্ধন চার্জ" autocomplete="off" required="">

                                                        <?php $__errorArgs = ['service_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label for="payment_type" class="col-form-label">পেমেন্ট প্রকার <span
                                                            style="color: red">*</span></label>
                                                    <select name="payment_type" id="payment_type" class="form-control"
                                                          required="">
                                                        <option value="" >নির্বাচন করুন</option>
                                                        <?php if($payment_methods): ?>
                                                        <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo old('payment_type', $user->payment_method_id ) == $payment->id ? 'selected="selected"' : ''; ?> value="<?php echo e($payment->id); ?>"><?php echo e($payment->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
                                                    </select>

                                                    <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success">আপডেট</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
    </div>
    </section>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
            $(document).on('change', "#gurdian_status", function() {
                var gurdian_status = $("#gurdian_status").val();
                if (gurdian_status == 'father') {
                    // $(".gurdian_status").attr("name", "father_name");
                    $(".gurdian_status").attr("placeholder", "পিতার নাম");
                } else {
                    // $(".gurdian_status").attr("name", "husband_name");
                    $(".gurdian_status").attr("placeholder", "স্বামীর নাম");
                }
            });

            $(document).on('change', "#birth_nid", function() {
                var birth_nid = $("#birth_nid").val();
                if (birth_nid == 'nid') {
                    // $(".birth_nid").attr("name", "nid");
                    $(".birth_nid").attr("placeholder", "এনআইডি");
                } else {
                    // $(".birth_nid").attr("name", "birth_certificate");
                    $(".birth_nid").attr("placeholder", "জন্ম নিবন্ধন নম্বর");
                }
            });

            $(document).on('change', '#ward_id', function() {
                var id = $('#ward_id').val();
                $.ajax({
                    url: "<?php echo e(url('/getvillageinfo/')); ?>/" + id,

                    type: "GET",
                    dataType: "html",
                    success: function(data) {


                        if (data == 'no_data') {
                            toastr.error("Sorry, No Data Found");
                            $("#village_id").html(
                                '<option value="" selected="" disabled="">নির্বাচন করুন</option>'
                            );
                        } else {
                            $("#village_id").html(data);
                        }





                    },

                });
            });


            $(document).on('change', '#post_code_id', function() {
                var id = $('#post_code_id').val();
                $.ajax({
                    url: "<?php echo e(url('/get-post_office/')); ?>/" + id,

                    type: "GET",
                    dataType: "html",
                    success: function(data) {


                        if (data == 'no_data') {
                            toastr.error("Sorry, No Data Found");
                            $("#post_office_id").html(
                                '<option value="" selected="" disabled="">--নির্বাচন করুন--</option>'
                            );
                        } else {
                            $("#post_office_id").html(data);
                        }






                    },

                });
            });
            //house_tax_rate
            $(document).on('change', '#type_house', function() {
                var id = $("#type_house").val();
                var house_tax_rate = $("#house_tax_rate").val();
                $.ajax({
                    url: "<?php echo e(url('/get-house_tax_rate/')); ?>/" + id,

                    type: "GET",
                    dataType: "html",
                    success: function(data) {



                        $("#house_tax_rate").val(data);



                    },

                });
            });

            $(document).on('input', '.house_year_value', function() {
                var type_house = $("#type_house").val();
                var house_year_value = $('.house_year_value').val();

                var house_tax_rate = $("#house_tax_rate").val();
                var parse_house_tax_rate = parseInt(house_tax_rate);
                var parse_house_year_value = parseInt(house_year_value);
                var result = parse_house_year_value + parse_house_year_value * parse_house_tax_rate / 100;

                $(".yearly_vat").val(result);




            });
function contactNumber(id) {
        // Only Number will write
        var element = document.getElementById(id);
        var regex = /[^0-9]/gi;
        element.value = element.value.replace(regex, "");
    }
              $(document).on('keyup', '.mobilenumber', function () {
            var mobile = $(this).val();
            $.get('<?php echo e(URL::to("getduplicatenumber")); ?>' + '/' + mobile, function (data) {
                if (data !== 'No') {
                    // alert(data);
                    $("#dupmobile").text(data);
                    $("#showSubmitButton").hide();
                } else {
                     $("#dupmobile").text('');
                    $("#showSubmitButton").show();
                }
            });
        });

            $(document).on('input', '.birth_nid', function() {
                var birth_nid = $('.birth_nid').val();
                var attr = $(this).attr('name');

                $.ajax({
                    url: "<?php echo e(url('/check-birth_nid')); ?>",

                    type: "GET",
                    data: {
                        'birth_nid': birth_nid,
                        'attr': attr
                    },
                    dataType: "html",
                    success: function(data) {

                        // if (birth_nid == "") {
                        //     $('.save_data').css('cursor', 'pointer');
                        // } else if (data == 'birth_exist') {
                        //     toastr.error("Already, This Birth Certificate Number has been exist");
                        //     $('.save_data').css('cursor', 'not-allowed');
                        // } else if (data == 'nid_exist') {
                        //     toastr.error("Already, This National ID Number has been exist");
                        //     $('.save_data').css('cursor', 'not-allowed');
                        // } else {
                        //     $('.save_data').css('cursor', 'pointer');
                        // }


                    },

                });
            });

        });
    </script>
<script>
  var loadFile = function(event) {
    var sizeInKB = event.target.files[0].size/1024; //Normally files are in bytes but for KB divide by 1024 and so on
var sizeLimit= 1024;

if (sizeInKB >= sizeLimit) {
    $("#perror").text("Max file size 1MB");
      $("#showSubmitButton").hide();
}else {
     $("#perror").text("");
       $("#showSubmitButton").show();
}

var validExtensions = ["jpg","jpeg","png"]
    var file = $("#photo").val().split('.').pop();
    if (validExtensions.indexOf(file) == -1) {
        $("#perror").text("Only formats are allowed : "+validExtensions.join(', '));
          $("#showSubmitButton").hide();

    }
    else {
     $("#perror").text("");
       $("#showSubmitButton").show();
}
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }

  };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/admin/active_members/bosotedit.blade.php ENDPATH**/ ?>