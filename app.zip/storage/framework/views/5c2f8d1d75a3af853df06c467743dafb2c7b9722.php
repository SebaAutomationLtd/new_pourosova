
<?php $__env->startSection('header'); ?>
    <section class="content-header pl-3">
        <h1>ওয়েবসাইট</h1>
        <ol class="breadcrumb">
            <li>
                <a href="">
                    <i class="fa fa-fw ti-home"></i> এসেসমেন্ট নিবন্ধন
                </a>
            </li>
            <!-- <li>সেবা কার্ড একটিভ প্যানেল</li> -->

        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="content-wrapper">


        <section class="content  card card-primary">
            <div class="container-fluid">
                <div class="row mb-2" style="margin-top: 20px">
                    <div class="col-sm-6">
                        <h4> ব্যাবসা প্রতিষ্ঠান আপডেট করুন</h4>
                    </div>
                    <!-- <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">হোম</a></li>
                            <li class="breadcrumb-item active"> বসতবাড়ী হোল্ডিং আপডেট করুন</li>
                        </ol>
                    </div> -->
                </div>
                <div class="row">
                    <div class="col-md-12">
          

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
                        <div class=" website-form form-group">
                            <!-- <div class="card-header">
                                <h3 class="card-title"> বসতবাড়ী হোল্ডিং আপডেট করুন</h3>
                            </div> -->
                            <form role="form" action="<?php echo e(route('update.business', $user->id)); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                 <?php
                                    $user_info = DB::table('users')->where('id',$user->user_id)->first();

                                    ?>

                                <h5><u>খানা প্রধানের তথ্য</u></h5>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label for="name" class="col-form-label">নাম <span
                                                style="color: red">*</span></label>
                                        <input type="text" name="name" value="<?php echo e(old('name', $user_info->name)); ?>" class="form-control"
                                            id="name" placeholder="নাম" autocomplete="off" required="">

                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="col-sm-4" id="father_name">
                                        <label for="father_name" class="col-form-label">
                                            <select id="gurdian_status" name="gurdian_status">
                                                <option <?php echo old('gurdian_status', $user->spouse) == null ? 'selected="selected"' : ''; ?>  value="father" >পিতার নাম </option>
                                                <option <?php echo old('gurdian_status', $user->father) == null ? 'selected="selected"' : ''; ?> value="husband" >স্বামীর নাম</option>
                                            </select>
                                            <span style="color: red">*</span></label>
                                        <?php if($user->spouse == null): ?>
                                            <input type="text" name="father_name" value="<?php echo e(old('father_name', $user->father)); ?>"
                                                class="form-control gurdian_status" id="father_name" autocomplete="off"
                                                placeholder="পিতার নাম " required="">

                                                <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <?php else: ?>
                                            <input type="text" name="father_name" value="<?php echo e(old('father_name',$user->spouse)); ?>"
                                                class="form-control gurdian_status" id="husband_name" autocomplete="off"
                                                placeholder="স্বামীর নাম " required="">

                                                <?php $__errorArgs = ['husband_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-4">
                                        <label for="mother_name" class="col-form-label">মাতার নাম <span
                                                style="color: red">*</span></label>
                                        <input type="text" name="mother_name" value="<?php echo e(old('mother_name', $user->mother)); ?>"
                                            class="form-control" id="mother_name" placeholder="মায়ের নাম"
                                            autocomplete="off" required="">

                                            <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                               


                                    <div class="col-sm-3">
                                        <label for="nid_birth" class="col-form-label">
                                            <select id="birth_nid" name="birth_nid">
                                                <option <?php echo old('birth_nid', $user->birth_certificate) == null ? 'selected="selected"' : ''; ?> value="nid">এনআইডি নম্বর</option>
                                                <option value="birth_id_no" <?php echo old('birth_nid', $user->nid) == null ? 'selected="selected"' : ''; ?>>জন্ম নিবন্ধন নম্বর</option>
                                            </select>
                                            <span style="color: red">*</span></label>
                                        <?php if($user->birth_certificate == null): ?>
                                            <input type="text" name="nid" value="<?php echo e(old('nid',$user->nid)); ?>"
                                                class="form-control birth_nid" id="nid_birth" autocomplete="off"
                                                placeholder="এনআইডি নম্বর" required="">

                                                <?php $__errorArgs = ['nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <?php else: ?>
                                            <input type="text" name="nid"
                                                value="<?php echo e(old('nid',$user->birth_certificate)); ?>" class="form-control birth_nid"
                                                id="nid_birth" autocomplete="off" placeholder="এনআইডি নম্বর" required="">

                                                <?php $__errorArgs = ['birth_certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-3">
                                        <label for="mobile" class="col-form-label">মোবাইল<span
                                                style="color: red">*</span></label>
                                         <input type="text" pattern="[0-9]+" oninput="contactNumber(this.id);" maxlength="11" class="form-control mobilenumber" id="mobile"
                                   placeholder="মোবাইল" name="mobilenumber" value="<?php echo e(old('mobilenumber',$user->mobile)); ?>" required="">
                                   <span id="dupmobile" style="color: red;"></span>

                                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>


                                    <div class="col-sm-3" style="margin-top: 5px;">
                                        <div class="form-group">
                                            <label for="business_type_id">ব্যবসার ধরণ<span
                                                style="color: red">*</span></label>
                                            <select id="business_type_id" name="business_type_id" class="form-control">
                                                <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                 <?php $__currentLoopData = $business_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businesst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($businesst->id); ?>" <?php echo old('business_type_id', $user->business_type_id ) == $businesst->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($businesst->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                            <?php $__errorArgs = ['family_class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>


                                   

                                </div>
                                <br />

                                <div class="form-group">







                                    <!-- Addess Information -->
                                    <div class="form-group">
                                        <h5><u>ঠিকানার তথ্য</u> </h5>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label for="ward_id" class="col-form-label">ওয়ার্ড নং <span
                                                        style="color: red">*</span></label>
                                                <select name="ward_id" id="ward_id" class="form-control"  >
                                                    <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                   
                                                    <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($ward->id); ?>"<?php echo old('ward_id', $user->ward_id ) == $ward->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($ward->ward_no); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php $__errorArgs = ['ward_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="village_id" class="col-form-label">গ্রাম <span
                                                        style="color: red">*</span></label>
                                                <select name="village_id" id="village_id" class="form-control"
                                                     >
                                                    <option value="" selected="" disabled="">নির্বাচন করুন</option>
                                                   
                                                    <?php $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $village): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($village->id); ?>" <?php echo old('village_id', $user->village_id ) == $village->id ? 'selected="selected"' : ''; ?>>
                                                            <?php echo e($village->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php $__errorArgs = ['village_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                               </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-4">
                                                <label for="road_moholla" class="col-form-label">মহল্লা <span
                                                        style="color: red">*</span> </label>
                                                <input type="text" name="road_moholla" value="<?php echo e(old('road_moholla',$user->road_moholla)); ?>"
                                                    class="form-control" id="road_moholla" placeholder="মহল্লা "
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['road_moholla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>   
                                            <div class="col-sm-4">
                                                <label for="holding_no" class="col-form-label">প্রতিষ্ঠানের হোল্ডিং নং<span
                                                        style="color: red">*</span> </label>
                                                <input type="text" name="holding_no" value="<?php echo e(old('holding_no',$user->holding_no)); ?>"
                                                    class="form-control" id="holding_no" placeholder="হোল্ডিং নং"
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['holding_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                              <div class="col-md-4">
                                                <label for="shopno" class="col-form-label">দোকান নং<span
                                                        style="color: red">*</span></label>
                                                <input type="text" name="shopno" value="<?php echo e(old('shopno',$user->shopno)); ?>"
                                                    class="form-control" id="shopno" placeholder="দোকান নং"
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['shopno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                              <div class="col-md-4">
                                                <label for="business_name" class="col-form-label">প্রতিষ্ঠানের নাম<span
                                                        style="color: red">*</span></label>
                                                <input type="text" name="business_name" value="<?php echo e(old('business_name',$user->business_name)); ?>"
                                                    class="form-control" id="business_name" placeholder="প্রতিষ্ঠানের নাম"
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="business_address" class="col-form-label">প্রতিষ্ঠানের ঠিকানা <span
                                                        style="color: red">*</span></label>
                                                        <textarea class="form-control" name="business_address" placeholder="প্রতিষ্ঠানের ঠিকানা "
                                                    autocomplete="off" required=""><?php echo e(old('business_address',$user->business_address)); ?></textarea>
                                                

                                                    <?php $__errorArgs = ['business_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="current_address" class="col-form-label">বর্তমান ঠিকানা  <span
                                                        style="color: red">*</span></label>
                                                        <textarea class="form-control" name="current_address" placeholder="বর্তমান ঠিকানা  "
                                                    autocomplete="off" required=""><?php echo e(old('current_address',$user->current_address)); ?></textarea>
                                                

                                                    <?php $__errorArgs = ['current_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="permanent_address" class="col-form-label"> স্থায়ী ঠিকানা  <span
                                                        style="color: red">*</span></label>
                                                        <textarea class="form-control" name="permanent_address" placeholder="স্থায়ী ঠিকানা  "
                                                    autocomplete="off" required=""><?php echo e(old('permanent_address',$user->permanent_address)); ?></textarea>
                                                

                                                    <?php $__errorArgs = ['permanent_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>



                                        </div>
                                    </div>

                                    <!-- Other Information -->
                                    <div class="form-group">
                                        <h5><u>অন্যান্য তথ্য</u> </h5>
                                        <div class="row">


                                           <div class="col-md-4">
                                                <label for="trade_fee" class="col-form-label">বাণিজ্য ফি<span
                                                        style="color: red">*</span></label>
                                                <input type="text" pattern="[0-9]+" name="trade_fee" value="<?php echo e(old('trade_fee',$user->trade_fee)); ?>"
                                                    class="form-control" id="trade_fee" placeholder="বাণিজ্য ফি"
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['trade_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                             <div class="col-md-4">
                                                <label for="vat" class="col-form-label">
ভ্যাট<span
                                                        style="color: red">*</span></label>
                                                <input type="text" pattern="[0-9]+" name="vat" value="<?php echo e(old('vat',$user->vat)); ?>"
                                                    class="form-control" id="vat" placeholder="ভ্যাট"
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['vat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="signboard_tax" class="col-form-label">
সাইনবোর্ড ট্যাক্স  <span
                                                        style="color: red">*</span></label>
                                                <input type="text" pattern="[0-9]+" name="signboard_tax" value="<?php echo e(old('signboard_tax',$user->signboard_tax)); ?>"
                                                    class="form-control" id="signboard_tax" placeholder="সাইনবোর্ড ট্যাক্স  "
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['signboard_tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="business_tax" class="col-form-label">
বাণিজ্য ট্যাক্স <span
                                                        style="color: red">*</span></label>
                                                <input type="text" pattern="[0-9]+" name="business_tax" value="<?php echo e(old('business_tax',$user->business_tax)); ?>"
                                                    class="form-control" id="business_tax" placeholder="বাণিজ্য ট্যাক্স "
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['business_tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="other_tax" class="col-form-label">
অন্যান্য ট্যাক্স  <span
                                                        style="color: red">*</span></label>
                                                <input type="text" pattern="[0-9]+" name="other_tax" value="<?php echo e(old('other_tax',$user->other_tax)); ?>"
                                                    class="form-control" id="other_tax" placeholder="অন্যান্য ট্যাক্স  "
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['other_tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                             <div class="col-md-4">
                                                <label for="trade_total" class="col-form-label">
মোট বাণিজ্য<span
                                                        style="color: red">*</span></label>
                                                <input type="text" pattern="[0-9]+" name="trade_total" value="<?php echo e(old('trade_total',$user->trade_total)); ?>"
                                                    class="form-control" id="trade_total" placeholder="মোট বাণিজ্য"
                                                    autocomplete="off" required="">

                                                    <?php $__errorArgs = ['trade_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                          

                                          


                                            <div class="col-sm-4">
                                                <label for="last_license_issue_year" class="col-form-label">সর্বশেষ পরিশোধিত অর্থবছর</label>
                                                <select name="last_license_issue_year" id="last_license_issue_year" class="form-control"
                                                     >
                                                    <option value="" >নির্বাচন করুন</option>
                                                   <?php
                                        $date_past = date("Y", strtotime('-10 year')); 
$date_year = date("Y");


                                                   ?>
                                                   <?php for($i=$date_year;$i>=$date_past;$i--): ?>
                                                    <option <?php echo old('last_license_issue_year', $user->last_license_issue_year ) == $i ? 'selected="selected"' : ''; ?> value="<?php echo e($i); ?>">
                                                        <?php echo e($i); ?></option>
                                                    <?php endfor; ?>
                                                 
                                                </select>
                                               
                                                <?php $__errorArgs = ['last_license_issue_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <h5><u>ছবি </u> </h5>
                                            <div class="row">
                                                <div class="col-sm-4">
                            <label for="photo" class="col-form-label">ছবি সংযুক্ত করুন</label>
                            <input type="file" id="photo" name="photo" onchange="loadFile(event)" class="form-control">
                            <span id="perror" style="color: red;"></span>
                        </div>
                        <div class="col-sm-4">
                            <img id="output" src="<?php if($user->photo): ?> <?php echo e(asset('img/'.$user->photo)); ?> <?php else: ?> https://via.placeholder.com/150 <?php endif; ?>" class="img-responsive img-thumbnail img-fluid">
                        </div>
                                            </div>
                                        </div>

                                        <!-- Other Information -->
                                        <br>
                                        <div class="form-group">
                                            <h5><u>পেমেন্ট সংগ্রহ করুন</u> </h5>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label for="service_charge" class="col-form-label">নিবন্ধন চার্জ<span
                                                            style="color: red">*</span></label>
                                                    <input type="text" pattern="[0-9]+" name="service_charge"
                                                        value="<?php echo e(old('service_charge',$user->service_charge)); ?>" class="form-control"
                                                        id="service_charge" placeholder="নিবন্ধন চার্জ" autocomplete="off" required="">

                                                        <?php $__errorArgs = ['service_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label for="payment_type" class="col-form-label">পেমেন্ট প্রকার <span
                                                            style="color: red">*</span></label>
                                                    <select name="payment_type" id="payment_type" class="form-control"
                                                          required="">
                                                        <option value="" >নির্বাচন করুন</option>
                                                        <?php if($payment_methods): ?>
                                                        <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo old('payment_type', $user->payment_method_id ) == $payment->id ? 'selected="selected"' : ''; ?> value="<?php echo e($payment->id); ?>"><?php echo e($payment->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
                                                    </select>

                                                    <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success">আপডেট</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
    </div>
    </section>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
            $(document).on('change', "#gurdian_status", function() {
                var gurdian_status = $("#gurdian_status").val();
                if (gurdian_status == 'father') {
                    // $(".gurdian_status").attr("name", "father_name");
                    $(".gurdian_status").attr("placeholder", "পিতার নাম");
                } else {
                    // $(".gurdian_status").attr("name", "husband_name");
                    $(".gurdian_status").attr("placeholder", "স্বামীর নাম");
                }
            });

            $(document).on('change', "#birth_nid", function() {
                var birth_nid = $("#birth_nid").val();
                if (birth_nid == 'nid') {
                    // $(".birth_nid").attr("name", "nid");
                    $(".birth_nid").attr("placeholder", "এনআইডি");
                } else {
                    // $(".birth_nid").attr("name", "birth_certificate");
                    $(".birth_nid").attr("placeholder", "জন্ম নিবন্ধন নম্বর");
                }
            });

            $(document).on('change', '#ward_id', function() {
                var id = $('#ward_id').val();
                $.ajax({
                    url: "<?php echo e(url('/getvillageinfo/')); ?>/" + id,

                    type: "GET",
                    dataType: "html",
                    success: function(data) {


                        if (data == 'no_data') {
                            toastr.error("Sorry, No Data Found");
                            $("#village_id").html(
                                '<option value="" selected="" disabled="">নির্বাচন করুন</option>'
                            );
                        } else {
                            $("#village_id").html(data);
                        }





                    },

                });
            });


            $(document).on('change', '#post_code_id', function() {
                var id = $('#post_code_id').val();
                $.ajax({
                    url: "<?php echo e(url('/get-post_office/')); ?>/" + id,

                    type: "GET",
                    dataType: "html",
                    success: function(data) {


                        if (data == 'no_data') {
                            toastr.error("Sorry, No Data Found");
                            $("#post_office_id").html(
                                '<option value="" selected="" disabled="">--নির্বাচন করুন--</option>'
                            );
                        } else {
                            $("#post_office_id").html(data);
                        }






                    },

                });
            });
            //house_tax_rate
            $(document).on('change', '#type_house', function() {
                var id = $("#type_house").val();
                var house_tax_rate = $("#house_tax_rate").val();
                $.ajax({
                    url: "<?php echo e(url('/get-house_tax_rate/')); ?>/" + id,

                    type: "GET",
                    dataType: "html",
                    success: function(data) {



                        $("#house_tax_rate").val(data);



                    },

                });
            });

            $(document).on('input', '.house_year_value', function() {
                var type_house = $("#type_house").val();
                var house_year_value = $('.house_year_value').val();

                var house_tax_rate = $("#house_tax_rate").val();
                var parse_house_tax_rate = parseInt(house_tax_rate);
                var parse_house_year_value = parseInt(house_year_value);
                var result = parse_house_year_value + parse_house_year_value * parse_house_tax_rate / 100;

                $(".yearly_vat").val(result);




            });
function contactNumber(id) {
        // Only Number will write
        var element = document.getElementById(id);
        var regex = /[^0-9]/gi;
        element.value = element.value.replace(regex, "");
    }
              $(document).on('keyup', '.mobilenumber', function () {
            var mobile = $(this).val();
            $.get('<?php echo e(URL::to("getduplicatenumber")); ?>' + '/' + mobile, function (data) {
                if (data !== 'No') {
                    // alert(data);
                    $("#dupmobile").text(data);
                    $("#showSubmitButton").hide();
                } else {
                     $("#dupmobile").text('');
                    $("#showSubmitButton").show();
                }
            });
        });

            $(document).on('input', '.birth_nid', function() {
                var birth_nid = $('.birth_nid').val();
                var attr = $(this).attr('name');

                $.ajax({
                    url: "<?php echo e(url('/check-birth_nid')); ?>",

                    type: "GET",
                    data: {
                        'birth_nid': birth_nid,
                        'attr': attr
                    },
                    dataType: "html",
                    success: function(data) {

                        // if (birth_nid == "") {
                        //     $('.save_data').css('cursor', 'pointer');
                        // } else if (data == 'birth_exist') {
                        //     toastr.error("Already, This Birth Certificate Number has been exist");
                        //     $('.save_data').css('cursor', 'not-allowed');
                        // } else if (data == 'nid_exist') {
                        //     toastr.error("Already, This National ID Number has been exist");
                        //     $('.save_data').css('cursor', 'not-allowed');
                        // } else {
                        //     $('.save_data').css('cursor', 'pointer');
                        // }


                    },

                });
            });

        });
    </script>
<script>
  var loadFile = function(event) {
    var sizeInKB = event.target.files[0].size/1024; //Normally files are in bytes but for KB divide by 1024 and so on
var sizeLimit= 1024;

if (sizeInKB >= sizeLimit) {
    $("#perror").text("Max file size 1MB");
      $("#showSubmitButton").hide();
}else {
     $("#perror").text("");
       $("#showSubmitButton").show();
}

var validExtensions = ["jpg","jpeg","png"]
    var file = $("#photo").val().split('.').pop();
    if (validExtensions.indexOf(file) == -1) {
        $("#perror").text("Only formats are allowed : "+validExtensions.join(', '));
          $("#showSubmitButton").hide();

    }
    else {
     $("#perror").text("");
       $("#showSubmitButton").show();
}
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }

  };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/admin/active_members/businessedit.blade.php ENDPATH**/ ?>