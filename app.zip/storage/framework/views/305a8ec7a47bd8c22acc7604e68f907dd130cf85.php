<?php $__env->startSection('header'); ?>
    <section class="content-header pl-3">
        <h1>ওয়েবসাইট</h1>
        <ol class="breadcrumb">
            <li>
                <a href="">
                    <i class="fa fa-fw ti-home"></i> এসেসমেন্ট নিবন্ধন
                </a>
            </li>
            <!-- <li>সেবা কার্ড একটিভ প্যানেল</li> -->

        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row mb-2" style="margin-top: 20px">
                    <div class="col-sm-6">
                        <h4>সেবা কার্ড একটিভ প্যানেল</h4>
                    </div>

                </div>
                <div class="row">
                    <!-- /.col -->
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                সেবা কার্ড একটিভ প্যানেল
                            </div>

                            <div class="card-body">
                                <?php if(count($users) == 0): ?>
                                    কোন তথ্য খুজে পাওয়া যায়নি
                                <?php else: ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $user_info = DB::table('users')->where('id',$user->user_id)->first();

                                    ?>
                                        <table class="table table-hover table-bordered">
                                            <tr>
                                                <th>নাম</th>
                                                <th>ইউজার আইডি</th>
                                                <th>ওয়ার্ড</th>
                                                <th>স্টাটাস</th>
                                                <th>একশন</th>
                                            </tr>
                                            <tr>
                                                <td><?php echo e($user_info->name ?? ''); ?></td>
                                                <td><?php echo e($user->user_id); ?></td>
                                                <td><?php echo e($user->ward_id); ?></td>
                                                <td>
                                                    <?php if($user->status == 1): ?>
                                                    <span class="badge badge-success">একটিভ</span>
                                                    <?php else: ?>
                                                     <span class="badge badge-danger">ডিএকটিভ</span>
                                                     <?php endif; ?> 
                                                    </td>
                                                <td>
                                                    <a href="<?php echo e(route('action.show', [$user->id, $type])); ?>"
                                                        class="btn btn-primary">বিস্তারিত দেখুন</a>  
                                                        <?php if($user->status == 0): ?>
                                                <a href="<?php echo e(route('action.activeshow', [$user->id, $type])); ?>"
                                                    class="btn btn-success">একটিভ করুন</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('action.deactivePanel', [$user->id, $type])); ?>"
                                                    class="btn btn-danger">ডিএকটিভ করুন</a>
                                            <?php endif; ?>

                                            <a href="<?php echo e(route('action.edit', [$user->id, $type])); ?>"
                                                        class="btn btn-info">এডিট করুন</a>

                                                </td>
                                            </tr>
                                        </table>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/admin/active_members/result.blade.php ENDPATH**/ ?>