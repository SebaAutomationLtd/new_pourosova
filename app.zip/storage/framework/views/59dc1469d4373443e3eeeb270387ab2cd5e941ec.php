
<?php $__env->startSection('header'); ?>
    <section class="content-header pl-3">
        <h1>ওয়েবসাইট</h1>
        <ol class="breadcrumb">
            <li>
                <a href="index.html">
                    <i class="fa fa-fw ti-home"></i> হেডার
                </a>
            </li>
            <li> লোগো</li>

        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card main-chart">
                <div class="card-header panel-tabs">
                    <h5>হোম পেইজ স্লাইডার</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.index.slider')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-sm-4 col-md-2">
                                <label for="">ছবির সিরিয়াল</label>
                                <select name="serial" id="type" class="custom-select">
                                    <option value="">-- সিলেক্ট --</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                </select>

                                <?php $__errorArgs = ['serial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class=text-danger><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-sm-8 col-md-10">
                                <label for="">JPG ছবি (500px * 300px)</label>
                                <div class="custom-file">
                                    <input name="image" type="file" class="custom-file-input" id="customFileLang" lang="es">
                                    <label class="custom-file-label" for="customFileLang">ছবি (JPG Format) (500px *
                                        300px)</label>
                                </div>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class=text-danger><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-sm-4 col-md-4">
                                <label for="title">টাইটেল</label>
                                <input class="form-control" id="title" name="title" type="text">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class=text-danger><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <button class="btn btn-primary">সাবমিট</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-12 mt-4">
            <div class="card main-chart mt-4 mt-md-0">
                <div class="card-header panel-tabs">
                    <h5>হোম পেইজ স্লাইডার</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php
                        $no = 1;
                        ?>

                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="image col-md-6 mt-4">

                            <span class="image-no" style="color: blue; font-size: 25px; font-family: initial; font-weight: bold; "><?php echo e($no++); ?>

                                <a data-placement="left" id="delete" title="ডিলেট করুন" data="tooltip"
                                    class="text-danger dropdown-item" href="<?php echo e(route('admin.index.slider.delete',$slider->id ?? '')); ?>">
                                  <i class="fa fa-trash"></i>
                                </a>
                            </span>

                            <img src="<?php echo e(asset('img/'.$slider->image ?? '')); ?>"  class="d-blok w-100 rounded border"
                                alt="">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>


                </div>
            </div>
        </div>


    </div>





<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp-1-11-21\htdocs\new_pourosova\resources\views/admin/index/slider.blade.php ENDPATH**/ ?>