@include ('frontend.include.header')
@include ('frontend.include.leftbar')

                <!-- Content Column End -->
                <div class="col-md-6 order-md-2 order-1" id="content">
                    <div>
                        <div>
                            <!--Description Start-->
                            <div class="welcome mb-3" id="mayor-list">
                                <div class="content-header">
                                    <h5 class="m-0 font-weight-bold">সম্মানিত কাউন্সিলরগণ</h5>
                                </div>
                                <div class="padding-15">

                                    <!--Mayor Name-->
                                    <div class="mayor-item">
                                        <div
                                            class="d-flex mt-3 justify-content-sm-start justify-content-center flex-wrap align-items-center">
                                            <div class="image">
                                                <img class="d-block" src="images/photos/Shafiqul-Islam-Chowdhury.jpg"
                                                    alt="">
                                            </div>
                                            <div class="title ml-3 mt-2 mt-sm-0 text-center text-sm-left">
                                                <b class="name">মোঃ রফিকুল ইসলাম</b>
                                                <div>
                                                    কাউন্সিলর <br>ওয়ার্ড নং - ০১ <br><i
                                                        class="mr-1 fa fa-phone-alt"></i>
                                                    ০১৭১২২৪৬০৫১
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!--Mayor Name-->
                                    <div class="mayor-item">
                                        <div
                                            class="d-flex mt-3 justify-content-sm-start justify-content-center flex-wrap align-items-center">
                                            <div class="image">
                                                <img class="d-block" src="images/photos/Shafiqul-Islam-Chowdhury.jpg"
                                                    alt="">
                                            </div>
                                            <div class="title ml-3 mt-2 mt-sm-0 text-center text-sm-left">
                                                <b class="name">মোঃ রফিকুল ইসলাম</b>
                                                <div>
                                                    কাউন্সিলর <br>ওয়ার্ড নং - ০১ <br><i
                                                        class="mr-1 fa fa-phone-alt"></i>
                                                    ০১৭১২২৪৬০৫১
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!--Mayor Name-->
                                    <div class="mayor-item">
                                        <div
                                            class="d-flex mt-3 justify-content-sm-start justify-content-center flex-wrap align-items-center">
                                            <div class="image">
                                                <img class="d-block" src="images/photos/Shafiqul-Islam-Chowdhury.jpg"
                                                    alt="">
                                            </div>
                                            <div class="title ml-3 mt-2 mt-sm-0 text-center text-sm-left">
                                                <b class="name">মোঃ রফিকুল ইসলাম</b>
                                                <div>
                                                    কাউন্সিলর <br>ওয়ার্ড নং - ০১ <br><i
                                                        class="mr-1 fa fa-phone-alt"></i>
                                                    ০১৭১২২৪৬০৫১
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!--Mayor Name-->
                                    <div class="mayor-item">
                                        <div
                                            class="d-flex mt-3 justify-content-sm-start justify-content-center flex-wrap align-items-center">
                                            <div class="image">
                                                <img class="d-block" src="images/photos/Shafiqul-Islam-Chowdhury.jpg"
                                                    alt="">
                                            </div>
                                            <div class="title ml-3 mt-2 mt-sm-0 text-center text-sm-left">
                                                <b class="name">মোঃ রফিকুল ইসলাম</b>
                                                <div>
                                                    কাউন্সিলর <br>ওয়ার্ড নং - ০১ <br><i
                                                        class="mr-1 fa fa-phone-alt"></i>
                                                    ০১৭১২২৪৬০৫১
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!--Mayor Name-->
                                    <div class="mayor-item">
                                        <div
                                            class="d-flex mt-3 justify-content-sm-start justify-content-center flex-wrap align-items-center">
                                            <div class="image">
                                                <img class="d-block" src="images/photos/Shafiqul-Islam-Chowdhury.jpg"
                                                    alt="">
                                            </div>
                                            <div class="title ml-3 mt-2 mt-sm-0 text-center text-sm-left">
                                                <b class="name">মোঃ রফিকুল ইসলাম</b>
                                                <div>
                                                    কাউন্সিলর <br>ওয়ার্ড নং - ০১ <br><i
                                                        class="mr-1 fa fa-phone-alt"></i>
                                                    ০১৭১২২৪৬০৫১
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!--Mayor Name-->
                                    <div class="mayor-item">
                                        <div
                                            class="d-flex mt-3 justify-content-sm-start justify-content-center flex-wrap align-items-center">
                                            <div class="image">
                                                <img class="d-block" src="images/photos/Shafiqul-Islam-Chowdhury.jpg"
                                                    alt="">
                                            </div>
                                            <div class="title ml-3 mt-2 mt-sm-0 text-center text-sm-left">
                                                <b class="name">মোঃ রফিকুল ইসলাম</b>
                                                <div>
                                                    কাউন্সিলর <br>ওয়ার্ড নং - ০১ <br><i
                                                        class="mr-1 fa fa-phone-alt"></i>
                                                    ০১৭১২২৪৬০৫১
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!--Mayor Name-->
                                    <div class="mayor-item">
                                        <div
                                            class="d-flex mt-3 justify-content-sm-start justify-content-center flex-wrap align-items-center">
                                            <div class="image">
                                                <img class="d-block" src="images/photos/Shafiqul-Islam-Chowdhury.jpg"
                                                    alt="">
                                            </div>
                                            <div class="title ml-3 mt-2 mt-sm-0 text-center text-sm-left">
                                                <b class="name">মোঃ রফিকুল ইসলাম</b>
                                                <div>
                                                    কাউন্সিলর <br>ওয়ার্ড নং - ০১ <br><i
                                                        class="mr-1 fa fa-phone-alt"></i>
                                                    ০১৭১২২৪৬০৫১
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!--Mayor Name-->
                                    <div class="mayor-item">
                                        <div
                                            class="d-flex mt-3 justify-content-sm-start justify-content-center flex-wrap align-items-center">
                                            <div class="image">
                                                <img class="d-block" src="images/photos/Shafiqul-Islam-Chowdhury.jpg"
                                                    alt="">
                                            </div>
                                            <div class="title ml-3 mt-2 mt-sm-0 text-center text-sm-left">
                                                <b class="name">মোঃ রফিকুল ইসলাম</b>
                                                <div>
                                                    কাউন্সিলর <br>ওয়ার্ড নং - ০১ <br><i
                                                        class="mr-1 fa fa-phone-alt"></i>
                                                    ০১৭১২২৪৬০৫১
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Description End-->
                        </div>
                    </div>
                </div>
                <!-- Content Column End -->

@include ('frontend.include.rightbar')
@include ('frontend.include.footer')
