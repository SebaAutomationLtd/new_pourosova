@include ('frontend.include.header')
@include ('frontend.include.leftbar')
                <!-- Content Column End -->
                <div class="col-md-6 order-md-2 order-1" id="content">
                    <div>
                        <div>
                            <!--Description Start-->
                            <div class="welcome mb-3">
                                <div class="content-header">
                                    <h5 class="m-0 font-weight-bold">পৌরসভার কর্মকর্তা ও কর্মচারীবৃন্দ</h5>
                                </div>
                                <div class="padding-15 mt-2">
                                    <img class="d-block w-100" src="images/1.jpg" alt="">
                                </div>

                                <div class="padding-15 mt-2">
                                    <img class="d-block w-100" src="images/2.jpg" alt="">
                                </div>


                                <div class="padding-15 mt-2">
                                    <img class="d-block w-100" src="images/3.jpg" alt="">
                                </div>

                                <div class="padding-15 mt-2">
                                    <img class="d-block w-100" src="images/4.jpg" alt="">
                                </div>

                                <div class="padding-15 mt-2">
                                    <img class="d-block w-100" src="images/5.jpg" alt="">
                                </div>

                                <div class="padding-15 mt-2">
                                    <img class="d-block w-100" src="images/6.jpg" alt="">
                                </div>

                            </div>
                            <!--Description End-->
                        </div>
                    </div>
                </div>
                <!-- Content Column End -->
@include ('frontend.include.rightbar')
@include ('frontend.include.footer')
