<footer id="footer">
        <div class="container">
            <div class="footer text-center py-5">
                <div> Copyright &copy; 20121</div>
                <div>
                    কারিগরি সহযোগিতায় : <a href="#">Esoft Technology</a>
                </div>
            </div>
        </div>
    </footer>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script type="text/javascript" src="{{asset('js/admin/app.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/frontend/popper.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/frontend/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/frontend/custom.js')}}"></script>
</body>

</html>
