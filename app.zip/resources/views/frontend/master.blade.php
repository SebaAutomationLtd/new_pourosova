@include ('frontend.include.header')
@include ('frontend.include.leftbar')

<div class="col-md-6 order-md-2 order-1" id="content">
    <div>
        <div>

        </div>
    </div>
</div>

@include ('frontend.include.rightbar')
@include ('frontend.include.footer')
