<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;
use Validator;
 use URL;
 use DataTables;

class BosotBariController extends Controller
{
    public function NewBosotIndex()
    {
        return view('admin.bosotbari.index');
    }
     public function BosotSearchResult(Request $request)
    {

        if ($request->nid && $request->mobile) {
             if ($request->ajax()) {
            $data = DB::table('bosot_bari')
                ->join('users', 'bosot_bari.user_id', 'users.id')
                ->select('users.show_password', 'bosot_bari.*')
                ->where('bosot_bari.mobile', $request->mobile)
                ->where('bosot_bari.nid', $request->nid)
                ->orderBy('bosot_bari.id', 'DESC')
                ->get();
                
           return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('name', function($data) {
                $useri=DB::table('users')->where('id',$data->user_id)->first();
                return $useri->name;
            })
            ->addColumn('father', function($data) {
                if(isset($data->father)){
                    return $data->father;
                }else {
                    return $data->spouse;
                }
            })
            
            ->addColumn('status', function($data) {
                if($data->status == '1'){
                    return 'একটিভ ';
                }else{
                    return 'পেন্ডিং ';
                }
            })
            ->addColumn('action', function($row){
  $btn = '<a data-toggle="tooltip" title="" href="#" class="btn btn-info btn-sm quick-edit"  data-original-title="কুইক এডিট"><i class="fa fa-wrench"></i></a> 
  <a data-toggle="tooltip" title="" href="#" class="btn btn-success btn-sm quick-edit" data-original-title="এডিট করুন"><i class="fa fa-edit"></i></a>
  <a data-toggle="tooltip" title="" href="#" class="btn btn-danger btn-sm quick-edit" data-original-title="ডিলেট করুন"><i class="fa fa-trash"></i></a>';
     
                            return $btn;
               
                    })
                    ->rawColumns(['action'])
            ->make(true);
        }
            

        } elseif ($request->nid) {
             if ($request->ajax()) {
            $data = DB::table('bosot_bari')
                ->join('users', 'bosot_bari.user_id', 'users.id')
                ->select('users.show_password', 'bosot_bari.*')
                ->where('bosot_bari.nid', $request->nid)
                ->orderBy('bosot_bari.id', 'DESC')
                ->get();
                
           return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('name', function($data) {
                $useri=DB::table('users')->where('id',$data->user_id)->first();
                return $useri->name;
            })
            ->addColumn('father', function($data) {
                if(isset($data->father)){
                    return $data->father;
                }else {
                    return $data->spouse;
                }
            })
            
            ->addColumn('status', function($data) {
                if($data->status == '1'){
                    return 'একটিভ ';
                }else{
                    return 'পেন্ডিং ';
                }
            })
            ->addColumn('action', function($row){
  $btn = '<a data-toggle="tooltip" title="" href="#" class="btn btn-info btn-sm quick-edit"  data-original-title="কুইক এডিট"><i class="fa fa-wrench"></i></a> 
  <a data-toggle="tooltip" title="" href="#" class="btn btn-success btn-sm quick-edit" data-original-title="এডিট করুন"><i class="fa fa-edit"></i></a>
  <a data-toggle="tooltip" title="" href="#" class="btn btn-danger btn-sm quick-edit" data-original-title="ডিলেট করুন"><i class="fa fa-trash"></i></a>';
     
                            return $btn;
               
                    })
                    ->rawColumns(['action'])
            ->make(true);
        }
            
        } elseif ($request->mobile) {
             if ($request->ajax()) {
            $data = DB::table('bosot_bari')
                ->join('users', 'bosot_bari.user_id', 'users.id')
                ->select('users.show_password', 'bosot_bari.*')
                ->where('bosot_bari.mobile', $request->mobile)
                ->orderBy('bosot_bari.id', 'DESC')
                ->get();
                
           return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('name', function($data) {
                $useri=DB::table('users')->where('id',$data->user_id)->first();
                return $useri->name;
            })
            ->addColumn('father', function($data) {
                if(isset($data->father)){
                    return $data->father;
                }else {
                    return $data->spouse;
                }
            })
            
            ->addColumn('status', function($data) {
                if($data->status == '1'){
                    return 'একটিভ ';
                }else{
                    return 'পেন্ডিং ';
                }
            })
            ->addColumn('action', function($row){
  $btn = '<a data-toggle="tooltip" title="" href="#" class="btn btn-info btn-sm quick-edit"  data-original-title="কুইক এডিট"><i class="fa fa-wrench"></i></a> 
  <a data-toggle="tooltip" title="" href="#" class="btn btn-success btn-sm quick-edit" data-original-title="এডিট করুন"><i class="fa fa-edit"></i></a>
  <a data-toggle="tooltip" title="" href="#" class="btn btn-danger btn-sm quick-edit" data-original-title="ডিলেট করুন"><i class="fa fa-trash"></i></a>';
     
                            return $btn;
               
                    })
                    ->rawColumns(['action'])
            ->make(true);
        }
        
        } elseif ($request->ward_id && $request->village_id) {
             if ($request->ajax()) {
            $data = DB::table('bosot_bari')
                ->join('users', 'bosot_bari.user_id', 'users.id')
                ->select('users.show_password', 'bosot_bari.*')
                ->where('bosot_bari.ward_id', $request->ward_id)
                ->where('bosot_bari.village_id', $request->village_id)
                ->orderBy('bosot_bari.id', 'DESC')
                ->get();
                
           return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('name', function($data) {
                $useri=DB::table('users')->where('id',$data->user_id)->first();
                return $useri->name;
            })
            ->addColumn('father', function($data) {
                if(isset($data->father)){
                    return $data->father;
                }else {
                    return $data->spouse;
                }
            })
            
            ->addColumn('status', function($data) {
                if($data->status == '1'){
                    return 'একটিভ ';
                }else{
                    return 'পেন্ডিং ';
                }
            })
             ->addColumn('action', function($row){
                   $btn = '<a data-toggle="tooltip" title="" href="#" class="btn btn-info btn-sm quick-edit"  data-original-title="কুইক এডিট"><i class="fa fa-wrench"></i></a> 
                   <a data-toggle="tooltip" title="" href="#" class="btn btn-info btn-sm quick-edit" datsuccessiginal-title="কুইক এডিট"><i class="fa fa-wrench"></i></a>
                   <a data-toggle="tooltip" title="" href="#" class="btn btn-info btn-sm quick-edit" datdangeriginal-title="কুইক এডিট"><i class="fa fa-wrench"></i></a>';
     
                            return $btn;
                })

            
            ->rawColumns(['action'])
            ->make(true);
        }
            
        } elseif ($request->ward_id) {
             if ($request->ajax()) {
            $data = DB::table('bosot_bari')
                ->join('users', 'bosot_bari.user_id', 'users.id')
                ->select('users.show_password', 'bosot_bari.*')
                ->where('bosot_bari.ward_id', $request->ward_id)
                ->orderBy('bosot_bari.id', 'DESC')
                ->get();
                
           return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('name', function($data) {
                $useri=DB::table('users')->where('id',$data->user_id)->first();
                return $useri->name;
            })
            ->addColumn('father', function($data) {
                if(isset($data->father)){
                    return $data->father;
                }else {
                    return $data->spouse;
                }
            })
            
            ->addColumn('status', function($data) {
                if($data->status == '1'){
                    return 'একটিভ ';
                }else{
                    return 'পেন্ডিং ';
                }
            })
            ->addColumn('action', function($row){
  $btn = '<a data-toggle="tooltip" title="" href="#" class="btn btn-info btn-sm quick-edit"  data-original-title="কুইক এডিট"><i class="fa fa-wrench"></i></a> 
  <a data-toggle="tooltip" title="" href="#" class="btn btn-success btn-sm quick-edit" data-original-title="এডিট করুন"><i class="fa fa-edit"></i></a>
  <a data-toggle="tooltip" title="" href="#" class="btn btn-danger btn-sm quick-edit" data-original-title="ডিলেট করুন"><i class="fa fa-trash"></i></a>';
     
                            return $btn;
               
                    })
                    ->rawColumns(['action'])
            ->make(true);
        }
            
        } else {
             if ($request->ajax()) {
            $data = DB::table('bosot_bari')->where('ward_id', $request->ward_id)
                ->orWhere('village_id', $request->village_id)
                ->orWhere('mobile', $request->mobile)
                ->orWhere('nid', $request->birth_nid)
                ->orWhere('holding_no', $request->holding_no)
                ->orderBy('id', 'DESC')
                ->get();
                
           return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('name', function($data) {
                $useri=DB::table('users')->where('id',$data->user_id)->first();
                return $useri->name;
            })
            ->addColumn('father', function($data) {
                if(isset($data->father)){
                    return $data->father;
                }else {
                    return $data->spouse;
                }
            })
            
            ->addColumn('status', function($data) {
                if($data->status == '1'){
                    return 'একটিভ ';
                }else{
                    return 'পেন্ডিং ';
                }
            })
            ->addColumn('action', function($row){
  $btn = '<a data-toggle="tooltip" title="" href="#" class="btn btn-info btn-sm quick-edit"  data-original-title="কুইক এডিট"><i class="fa fa-wrench"></i></a> 
  <a data-toggle="tooltip" title="" href="#" class="btn btn-success btn-sm quick-edit" data-original-title="এডিট করুন"><i class="fa fa-edit"></i></a>
  <a data-toggle="tooltip" title="" href="#" class="btn btn-danger btn-sm quick-edit" data-original-title="ডিলেট করুন"><i class="fa fa-trash"></i></a>';
     
                            return $btn;
               
                    })
                    ->rawColumns(['action'])
            ->make(true);
        }
            
        }
        return view('admin.bosotbari.bosot_search_result');
    }
}
